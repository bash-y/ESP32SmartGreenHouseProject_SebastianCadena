#include <WiFi.h>
#include <WiFiClient.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

#include "Adafruit_MQTT.h"
#include "Adafruit_MQTT_Client.h"

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "DHT.h"

/******** WiFi (Wokwi) ********/
#define WLAN_SSID "Wokwi-GUEST"
#define WLAN_PASS ""

/******** Adafruit IO (MQTT) ********/
#define AIO_SERVER "io.adafruit.com"
#define AIO_SERVERPORT 1883
#define AIO_USERNAME "bashcadena"
#define AIO_KEY      "aio_LiXt80sYCXAp1EWKtk8qUOuJY6sp"

/******** OpenWeather ********/
#define OPENWEATHER_API_KEY "4e5311ac2f9a0686b05ab227280c0695"

String weatherUrl() {
  return String("http://api.openweathermap.org/data/2.5/weather?q=San%20Antonio,US&units=imperial&appid=") + OPENWEATHER_API_KEY;
}

/******** MQTT ********/
WiFiClient netClient;
Adafruit_MQTT_Client mqtt(&netClient, AIO_SERVER, AIO_SERVERPORT, AIO_USERNAME, AIO_KEY);

Adafruit_MQTT_Subscribe LEDfeed =
  Adafruit_MQTT_Subscribe(&mqtt, AIO_USERNAME "/feeds/LED");

// Match your feed keys exactly (yours were capitalized)
Adafruit_MQTT_Publish humidityFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/Humidity");

Adafruit_MQTT_Publish temperatureFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/Temperature");

Adafruit_MQTT_Publish moistureFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/Moisture");

Adafruit_MQTT_Publish lightFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/Light");

Adafruit_MQTT_Publish saTempFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/sa_temp_f");

Adafruit_MQTT_Publish saHumFeed =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/sa_humidity");

Adafruit_MQTT_Publish saWeatherTxt =
  Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/sa_weather");

/******** Hardware ********/
const int ledPin = 15;

#define DHTPIN 13
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

const int MOISTURE_PIN = 34;
const int LIGHT_PIN    = 35;

LiquidCrystal_I2C lcd(0x27, 16, 2);

/******** Timing ********/
unsigned long lastGreenhousePub = 0;
const unsigned long GREENHOUSE_MS = 10000;  // 10 seconds

unsigned long lastWeatherPub = 0;
const unsigned long WEATHER_MS = 30000;     // 30 seconds

unsigned long lastLcdCycle = 0;
const unsigned long LCD_MS = 5000;          // 5 seconds
int lcdScreen = 0;                          // 0..2

/******** Cached Values ********/
float ghTempF_cache = NAN;
float ghHum_cache   = NAN;
int light_cache     = 0;
int moist_cache     = 0;

float saTempF_cache = NAN;
float saHum_cache   = NAN;
String saWx_cache   = "N/A";

/******** Alerts ********/
bool alertNeedsWater = false;
bool alertTooWet     = false;
bool alertHeatRisk   = false;

/******** LED control ********/
bool manualLedOn = false;
bool autoLedOn   = false;

/******** Helpers ********/
int clampInt(int x, int lo, int hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

int toPercent(int raw) {
  raw = clampInt(raw, 0, 4095);
  return (int)(raw * 100.0f / 4095.0f + 0.5f);
}

void applyLedOutput() {
  bool finalLed = manualLedOn || autoLedOn;
  digitalWrite(ledPin, finalLed ? HIGH : LOW);
}

/******** Forward decl ********/
void MQTT_connect();
void ledCallback(char* message, uint16_t len);
void publishGreenhouse();
void publishSanAntonioWeather();
void updateLCD(bool forceRedraw);

/******** Setup ********/
void setup() {
  Serial.begin(115200);

  WiFi.begin(WLAN_SSID, WLAN_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(250);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");

  LEDfeed.setCallback(ledCallback);
  mqtt.subscribe(&LEDfeed);

  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);

  dht.begin();

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print("Booting...");
  lcd.setCursor(0, 1); lcd.print("WiFi OK");
  delay(800);

  updateLCD(true);
}

/******** Loop ********/
void loop() {
  MQTT_connect();
  mqtt.processPackets(50);

  // Publish greenhouse every 10s
  if (millis() - lastGreenhousePub >= GREENHOUSE_MS) {
    lastGreenhousePub = millis();
    publishGreenhouse();
    updateLCD(true);
  }

  // Refresh weather every 30s
  if (millis() - lastWeatherPub >= WEATHER_MS) {
    lastWeatherPub = millis();
    publishSanAntonioWeather();
    updateLCD(true);
  }

  // LCD cycle every 2s
  if (millis() - lastLcdCycle >= LCD_MS) {
    lastLcdCycle = millis();
    lcdScreen = (lcdScreen + 1) % 3;
    updateLCD(true);
  }

  mqtt.ping();
  delay(20);
}

/******** LED feed callback ********/
void ledCallback(char* message, uint16_t len) {
  if (strcmp(message, "ON") == 0 || strcmp(message, "1") == 0) manualLedOn = true;
  else manualLedOn = false;

  applyLedOutput();
}

/******** Publish greenhouse ********/
void publishGreenhouse() {
  float hum = dht.readHumidity();
  float tempC = dht.readTemperature();
  float tempF = tempC * 9.0 / 5.0 + 32.0;

  moist_cache = toPercent(analogRead(MOISTURE_PIN));
  light_cache = toPercent(analogRead(LIGHT_PIN));

  ghTempF_cache = tempF;
  ghHum_cache = hum;

  if (!isnan(tempF)) temperatureFeed.publish(tempF);
  if (!isnan(hum))   humidityFeed.publish(hum);

  moistureFeed.publish((int32_t)moist_cache);
  lightFeed.publish((int32_t)light_cache);

  // Reset alerts + auto LED
  alertNeedsWater = false;
  alertTooWet = false;
  alertHeatRisk = false;
  autoLedOn = false;

  // Rule: Needs water
  if (moist_cache < 30) {
    alertNeedsWater = true;
    autoLedOn = true;
  }

  // Rule: Too wet
  if (moist_cache > 80) {
    alertTooWet = true;
    autoLedOn = false;
  }

  // Rule: Heat risk
  if (!isnan(tempF) && tempF > 85.0) {
    alertHeatRisk = true;
  }

  applyLedOutput();

  Serial.print("GH T="); Serial.print(tempF); Serial.print("F ");
  Serial.print("H="); Serial.print(hum); Serial.print("% ");
  Serial.print("Moist="); Serial.print(moist_cache); Serial.print("% ");
  Serial.print("Light="); Serial.print(light_cache); Serial.println("%");
}

/******** Publish San Antonio weather ********/
void publishSanAntonioWeather() {
  if (String(OPENWEATHER_API_KEY) == "PASTE_OPENWEATHER_KEY_HERE") {
    Serial.println("Missing OpenWeather key.");
    return;
  }

  HTTPClient http;
  http.begin(weatherUrl());
  int code = http.GET();

  if (code != 200) {
    Serial.print("Weather HTTP error: ");
    Serial.println(code);
    http.end();
    return;
  }

  String payload = http.getString();
  http.end();

  StaticJsonDocument<2048> doc;
  DeserializationError err = deserializeJson(doc, payload);
  if (err) {
    Serial.print("JSON parse error: ");
    Serial.println(err.c_str());
    return;
  }

  saTempF_cache = doc["main"]["temp"] | NAN;
  saHum_cache   = doc["main"]["humidity"] | NAN;
  saWx_cache    = doc["weather"][0]["main"] | "N/A";

  if (!isnan(saTempF_cache)) saTempFeed.publish(saTempF_cache);
  if (!isnan(saHum_cache))   saHumFeed.publish(saHum_cache);
  saWeatherTxt.publish(saWx_cache.c_str());

  Serial.print("SA T="); Serial.print(saTempF_cache); Serial.print("F ");
  Serial.print("H="); Serial.print(saHum_cache); Serial.print("% ");
  Serial.print("Wx="); Serial.println(saWx_cache);
}

/******** LCD update (cycles screens, alerts override) ********/
void updateLCD(bool forceRedraw) {
  // Alerts override display (brief)
  if (alertNeedsWater) {
    lcd.clear();
    lcd.setCursor(0, 0); lcd.print("ALERT: Needs");
    lcd.setCursor(0, 1); lcd.print("Water! <30%");
    delay(1500);
    return;
  }

  if (alertTooWet) {
    lcd.clear();
    lcd.setCursor(0, 0); lcd.print("ALERT: Too Wet");
    lcd.setCursor(0, 1); lcd.print(">80% reduce H2O");
    delay(1500);
    return;
  }

  if (alertHeatRisk) {
    lcd.clear();
    lcd.setCursor(0, 0); lcd.print("ALERT: Heat");
    lcd.setCursor(0, 1); lcd.print("Risk Shade/Vent");
    delay(1500);
    return;
  }

  char line1[17];
  char line2[17];

  // Screen 0: GH top, SA bottom (temp/hum)
  if (lcdScreen == 0) {
    if (!isnan(ghTempF_cache) && !isnan(ghHum_cache)) {
      snprintf(line1, sizeof(line1), "GH T: %dF H: %d%%",
               (int)(ghTempF_cache + 0.5), (int)(ghHum_cache + 0.5));
    } else {
      snprintf(line1, sizeof(line1), "GH T: --F H: --%%");
    }

    if (!isnan(saTempF_cache) && !isnan(saHum_cache)) {
      snprintf(line2, sizeof(line2), "SA T: %dF H: %d%%",
               (int)(saTempF_cache + 0.5), (int)(saHum_cache + 0.5));
    } else {
      snprintf(line2, sizeof(line2), "SA T: --F H: --%%");
    }
  }

  // Screen 1: Light top, Moist bottom
  else if (lcdScreen == 1) {
    snprintf(line1, sizeof(line1), "Light: %d%%", light_cache);
    snprintf(line2, sizeof(line2), "Moisture: %d%%", moist_cache);
  }

  // Screen 2: SA Weather label + condition
  else {
    snprintf(line1, sizeof(line1), "SA Weather");
    // Condition might be longer than 16 chars, so truncate
    String cond = saWx_cache;
    if (cond.length() > 16) cond = cond.substring(0, 16);
    snprintf(line2, sizeof(line2), "%s", cond.c_str());
  }

  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(line1);
  lcd.setCursor(0, 1); lcd.print(line2);
}

/******** MQTT connect ********/
void MQTT_connect() {
  if (mqtt.connected()) return;

  Serial.print("Connecting to MQTT... ");
  uint8_t retries = 6;
  int8_t ret;

  while ((ret = mqtt.connect()) != 0) {
    Serial.println(mqtt.connectErrorString(ret));
    Serial.println("Retrying MQTT in 2 seconds...");
    mqtt.disconnect();
    delay(2000);
    if (--retries == 0) {
      Serial.println("MQTT failed.");
      return;
    }
  }
  Serial.println("MQTT Connected!");
}